$(document).ready(function() {

    //Slider Services //
    $("#owl-services").owlCarousel({
        singleItem: true,
        autoPlay: 3000, //Set AutoPlay to 3 seconds
        pagination: true,
    });

});
