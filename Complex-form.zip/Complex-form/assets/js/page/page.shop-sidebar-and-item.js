$(document).ready(function() {

    //SHOP THUMBNAIL SLIDER //
    $('.bxslider').bxSlider({
        pagerCustom: '#bx-pager-shop',
        controls: false
    });

});
